//
//  ProductListVMTests.swift
//  FlickrDemoTests
//
//  Created by Rajesh on 26/04/24.
//

import XCTest
@testable import FlickrDemo

final class ProductListVMTests: XCTestCase {
    var sut: ProductListVM!
    var mockService: MockProductService!
    override func setUpWithError() throws {
        mockService = MockProductService()
        sut = ProductListVM(proudctservice: mockService)
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        sut = nil
        mockService = nil
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testFetchProductList_Success()  {
        let expectation = XCTestExpectation(description: "Fetch Products Success")
        let mockProducts = [Product(id: 1, title: "iphone 12", thumbnail: "", description: "test", price: 40000),
                            Product(id: 1, title: "iphone X", thumbnail: "", description: "test", price: 10000),
                            Product(id: 1, title: "Samsung", thumbnail: "", description: "test", price: 30000)]
        sut.eventHandler = { event in
            if case .dataLoaded = event {
                expectation.fulfill()
            }
        }
        sut.fetchProductList()
        
        wait(for: [expectation], timeout: 1)
        XCTAssertEqual(sut.products, mockProducts)
        XCTAssertEqual(sut.filteredProducts, mockProducts)
    }
    
    func testFetchProductList_Failure ()  {
        let expectation = XCTestExpectation(description: "Fetch Products Fail")
        let errMessage = "Failed to fetch products"
        mockService.mockProductResult = .failure(.error(errMessage))
        
        sut.eventHandler = { event in
            if case .err(let error) = event {
                XCTAssertEqual(error, errMessage)
                expectation.fulfill()
            }
        }
        
        wait(for: [expectation], timeout: 1)
        XCTAssertTrue(sut.products.isEmpty)
        XCTAssertTrue(sut.filteredProducts.isEmpty)
    }
    
    func testFilterProducts() throws {
        let mockProducts = [Product(id: 1, title: "iphone 12", thumbnail: "", description: "test", price: 40000),
                            Product(id: 1, title: "iphone X", thumbnail: "", description: "test", price: 10000),
                            Product(id: 1, title: "Samsung", thumbnail: "", description: "test", price: 30000)]
        sut.products = mockProducts
        sut.getFilteredProducts(searchText: "iphone X")
        XCTAssertEqual(sut.filteredProducts.count, 1)
        XCTAssertEqual(sut.filteredProducts.first?.title, "iphone X")
    }
    

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
