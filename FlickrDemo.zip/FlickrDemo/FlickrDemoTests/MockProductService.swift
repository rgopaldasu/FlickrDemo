//
//  MockProductService.swift
//  FlickrDemoTests
//
//  Created by Rajesh on 26/04/24.
//

import Foundation
@testable import FlickrDemo

class MockProductService: ProductSeviceProtocol {
    var mockProductResult: Result<[Product], CustomError>?
    func fetchProducts(completion: @escaping (Result<[FlickrDemo.Product], FlickrDemo.CustomError>) -> ()) {
        if let result = mockProductResult {
            completion(result)
        }
    }
}
