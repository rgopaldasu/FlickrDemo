//
//  ProductService.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import Foundation

protocol ProductSeviceProtocol {
    func fetchProducts(completion: @escaping(Result<[Product], CustomError>) -> ())
}

class ProductService: ProductSeviceProtocol {
    let productsUrl = "https://dummyjson.com/products"
    
    func fetchProducts(completion: @escaping (Result<[Product], CustomError>) -> ()) {
        NetworkManager.shared.fetchData(strUrl: productsUrl, type: ProductList.self) { result in
            switch result {
            case .success(let productlist):
                completion(.success(productlist.products))
            case .failure(let err):
                completion(.failure(err))
            }
        }
    }
}


