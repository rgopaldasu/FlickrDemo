//
//  ProductListVM.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import Foundation

final class ProductListVM {
    let proudctservice: ProductSeviceProtocol
    var products: [Product] = []
    var filteredProducts: [Product] = []
    var eventHandler: ((_ event: Event) -> Void)?
 
    init(proudctservice: ProductSeviceProtocol = ProductService()) {
        self.proudctservice = proudctservice
    }
    
    func fetchProductList () {
        eventHandler?(.startLoading)
        proudctservice.fetchProducts {[weak self] result in
            guard let self = self else { return }
            self.eventHandler?(.stopLoading)
            switch result {
            case .success(let products):
                DispatchQueue.main.async {
                    self.products = products
                    self.filteredProducts = products
                    self.eventHandler?(.dataLoaded)
                }
            case .failure(let error):
                print(error)
                switch error {
                case .invalidurl:
                    self.eventHandler?(.err("Invalid Url"))
                case .invalidData:
                    self.eventHandler?(.err("Invalid Data"))
                case .error(let strErr):
                    self.eventHandler?(.err(strErr))
                }
            }
        }
    }
    
    func getFilteredProducts(searchText: String) {
        if searchText.isEmpty {
            filteredProducts = products
        } else {
            filteredProducts = products.filter{$0.title.lowercased().contains(searchText.lowercased())}
        }
    }
}

enum Event {
    case startLoading
    case stopLoading
    case dataLoaded
    case err(String)
}
