//
//  ProductModel.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import Foundation

struct Product: Decodable, Equatable {
    let id: Int
    let title: String
    let thumbnail: String
    let description: String
    let price: Int
}

struct ProductList: Decodable {
    let products:[Product]
}
