//
//  ViewController.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import UIKit

class ProductListVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    let viewModel = ProductListVM()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        observeEvents()
        fetchProducts()
    }
    
    func observeEvents() {
        viewModel.eventHandler = { event in
            switch event {
            case .startLoading:
                print("Start Loading")  // start progress Indicator
            case .stopLoading:
                print("Stop Loading") // stop progress Indicator
            case .dataLoaded:
                print("Data loaded")
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .err(let strError):
                print(strError)
            }
        }
    }
    
    func fetchProducts() {
        viewModel.fetchProductList()
    }
}

extension ProductListVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.filteredProducts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: ProductCell.cellIdentifier, for: indexPath) as? ProductCell {
            cell.displayData(product: viewModel.filteredProducts[indexPath.row])
            return cell
        }
        return ProductCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let productDetailVC = productDetailVC(index: indexPath.row)
        self.navigationController?.pushViewController(productDetailVC
                                                      , animated: true)
    }
    
    private func productDetailVC(index: Int) -> ProductDetailVC {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let productDetailVC = storyBoard.instantiateViewController(withIdentifier: "ProductDetailVC") as! ProductDetailVC
        productDetailVC.viewModel = ProductDetailVM(product: viewModel.filteredProducts[index])
        return productDetailVC
    }
}

extension ProductListVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.getFilteredProducts(searchText: searchText)
        self.tableView.reloadData()
    }
}



