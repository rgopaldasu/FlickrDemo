//
//  ProductCell.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import UIKit

class ProductCell: UITableViewCell {
    static let cellIdentifier = "ProductCell"
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func displayData(product: Product){
        self.lblTitle.text = product.title
        self.lblPrice.text = String("Price - \(product.price)")
        self.imgView.setImageWithUrl(strUrl: product.thumbnail)
    }
}



