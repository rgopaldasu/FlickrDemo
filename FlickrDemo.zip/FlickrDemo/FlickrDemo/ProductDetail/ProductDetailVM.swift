//
//  ProductDetailVM.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import Foundation

final class ProductDetailVM {
    private let product: Product
    
    init(product: Product) {
        self.product = product
    }

    var title: String {
        return product.title
    }
    
    var imgUrl: String {
        return product.thumbnail
    }
    
    var description: String {
        return product.description
    }
    
    var price: String {
        return "Price: \(product.price)"
    }
}

