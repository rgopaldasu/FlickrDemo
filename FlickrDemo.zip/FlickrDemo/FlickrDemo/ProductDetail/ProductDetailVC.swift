//
//  ProductDetailVC.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import UIKit

class ProductDetailVC: UIViewController {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    var viewModel: ProductDetailVM?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if let vm = viewModel {
            lblTitle.text = vm.title
            imgView.setImageWithUrl(strUrl: vm.imgUrl)
            lblPrice.text = vm.price
            lblDescription.text = vm.description
        }
    }

}
