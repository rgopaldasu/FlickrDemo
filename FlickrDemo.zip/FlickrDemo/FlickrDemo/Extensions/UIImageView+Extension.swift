//
//  UIImageView+Extension.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import Foundation
import UIKit

extension UIImageView {
    func setImageWithUrl(strUrl: String){
        guard let url = URL(string: strUrl) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let data = data {
                DispatchQueue.main.async {
                    self.image = UIImage(data: data)
                }
            } else {
                self.image = UIImage(systemName: "photo.artframe")
            }
        }.resume()
    }
}
