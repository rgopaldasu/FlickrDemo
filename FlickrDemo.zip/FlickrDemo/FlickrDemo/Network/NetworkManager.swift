//
//  NetworkManager.swift
//  FlickrDemo
//
//  Created by Rajesh on 26/04/24.
//

import Foundation

protocol NetworkManagerProtocol {
    func fetchData<T: Decodable> (strUrl: String, type: T.Type, completion: @escaping(Result<T, CustomError>) -> ())
}

class NetworkManager:  NetworkManagerProtocol{
    static let shared = NetworkManager()
    private init() {}
    
    func fetchData<T: Decodable> (strUrl: String, type: T.Type, completion: @escaping(Result<T, CustomError>) -> ()){
        guard let url = URL(string: strUrl) else {
            completion(.failure(.invalidurl))
            return
        }
        URLSession.shared.dataTask(with: url){ (data, response, err) in
            if let data = data {
                do {
                    let result = try JSONDecoder().decode(T.self, from: data)
                    completion(.success(result))
                } catch {
                    completion(.failure(.invalidData))
                }
            } else if let error = err {
                completion(.failure(.error(error.localizedDescription)))
            }
        }.resume()
    }
}

enum CustomError: Error {
    case invalidurl
    case invalidData
    case error(String)
}
